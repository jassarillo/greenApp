<div class="row mB-40">
	<div class="col-sm-8">
		<div class="bgc-white p-20 bd">
			<?php echo Form::myInput('text', 'name', 'Nombre de usuario'); ?>

		
			<?php echo Form::myInput('email', 'email', 'Correo'); ?>

	
			<?php echo Form::myInput('password', 'password', 'Contraseña'); ?>

	
			<?php echo Form::myInput('password', 'password_confirmation', 'Repetir Contraseña'); ?>

	
			<?php echo Form::mySelect('role', 'Rol', config('variables.role'), null, ['class' => 'form-control select2']); ?>

	
			<?php echo Form::myFile('avatar', 'Avatar'); ?>

	
			<?php echo Form::myTextArea('bio', 'Bio'); ?>

		</div>  
	</div>
</div><?php /**PATH /Applications/MAMP/htdocs/greenAppWeb/resources/views/admin/users/form.blade.php ENDPATH**/ ?>