<div class="row mB-40">
	<div class="col-sm-8">
		<div class="bgc-white p-20 bd">
			<?php echo Form::myInput('text', 'name', 'Username'); ?>

		
			<?php echo Form::myInput('email', 'email', 'Email'); ?>

	
			<?php echo Form::myInput('password', 'password', 'Password'); ?>

	
			<?php echo Form::myInput('password', 'password_confirmation', 'Password again'); ?>

	
			<?php echo Form::mySelect('role', 'Role', config('variables.role'), null, ['class' => 'form-control select2']); ?>

	
			<?php echo Form::myFile('avatar', 'Avatar'); ?>

	
			<?php echo Form::myTextArea('bio', 'Bio'); ?>

		</div>  
	</div>
</div><?php /**PATH C:\laragon\www\laradminator\resources\views/admin/users/form.blade.php ENDPATH**/ ?>