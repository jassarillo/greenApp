<?php $__env->startSection('page-header'); ?>
	User <small><?php echo e(trans('app.add_new_item')); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php echo Form::open([
			'action' => ['UserController@store'],
			'files' => true
		]); ?>


		<?php echo $__env->make('admin.users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<button type="submit" class="btn btn-primary"><?php echo e(trans('app.add_button')); ?></button>
		
	<?php echo Form::close(); ?>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laradminator\resources\views/admin/users/create.blade.php ENDPATH**/ ?>