

<?php $__env->startSection('page-header'); ?>
    Usuarios <small><?php echo e(trans('app.manage')); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="mB-20">
        <a href="<?php echo e(route(ADMIN . '.users.create')); ?>" class="btn btn-info">
            <?php echo e(trans('app.add_button')); ?>

        </a>
    </div>


    <div class="bgc-white bd bdrs-3 p-20 mB-20">
        <table id="dataTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            
            <tfoot>
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Acciones</th>
                </tr>
            </tfoot>
            
            <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route(ADMIN . '.users.edit', $item->id)); ?>"><?php echo e($item->name); ?></a></td>
                        <td><?php echo e($item->email); ?></td>
                        <td>
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <a href="<?php echo e(route(ADMIN . '.users.edit', $item->id)); ?>" title="<?php echo e(trans('app.edit_title')); ?>" class="btn btn-primary btn-sm"><span class="ti-pencil"></span></a></li>
                                <li class="list-inline-item">
                                    <?php echo Form::open([
                                        'class'=>'delete',
                                        'url'  => route(ADMIN . '.users.destroy', $item->id), 
                                        'method' => 'DELETE',
                                        ]); ?>


                                        <button class="btn btn-danger btn-sm" title="<?php echo e(trans('app.delete_title')); ?>"><i class="ti-trash"></i></button>
                                        
                                    <?php echo Form::close(); ?>

                                </li>
                            </ul>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/greenAppWeb/resources/views/admin/users/index.blade.php ENDPATH**/ ?>