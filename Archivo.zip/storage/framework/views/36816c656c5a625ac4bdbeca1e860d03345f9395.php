

<?php $__env->startSection('content'); ?>

    <h4 class="fw-300 c-grey-900 mB-40">Register</h4>
    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo e(csrf_field()); ?>


        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
            <label for="name" class="text-normal text-dark">Name</label>
            <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

            <?php if($errors->has('name')): ?>
                <span class="form-text text-danger">
                    <small><?php echo e($errors->first('name')); ?></small>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <label for="email" class="text-normal text-dark">Email</label>
            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

            <?php if($errors->has('email')): ?>
                <span class="form-text text-danger">
                    <small><?php echo e($errors->first('email')); ?></small>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <label for="password" class="text-normal text-dark">password</label>
            <input id="password" type="password" class="form-control" name="password" required>

            <?php if($errors->has('password')): ?>
                <span class="form-text text-danger">
                    <small><?php echo e($errors->first('password')); ?></small>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="password_confirmation" class="text-normal text-dark">Confirm Password</label>
            <input id="password_confirmation" type="password" class="form-control" name="password_confirmation" required>

        </div>

        <div class="form-group">
            <div class="peers ai-c jc-sb fxw-nw">
                <div class="peer">
                    <a href="/login">I have an account</a>
                </div>
                <div class="peer">
                    <button class="btn btn-primary">Register</button>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laradminator/resources/views/auth/register.blade.php ENDPATH**/ ?>